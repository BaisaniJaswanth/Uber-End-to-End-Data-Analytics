import io
import pandas as pd
import requests

if 'data_loader' not in globals():
    from mage_ai.data_preparation.decorators import data_loader
if 'test' not in globals():
    from mage_ai.data_preparation.decorators import test


@data_loader
def load_data_from_api(*args, **kwargs):
    """
    Load data from an Excel file hosted on a URL.
    """
    url = 'https://storage.googleapis.com/uber-data-engineering-project-jaswanth/UberDatasetCleaned.xlsx'
    response = requests.get(url)

    # Correct handling of binary Excel (.xlsx) content
    return pd.read_excel(io.BytesIO(response.content))


@test
def test_output(output, *args) -> None:
    """
    Template code for testing the output of the block.
    """
    assert output is not None, 'The output is undefined'