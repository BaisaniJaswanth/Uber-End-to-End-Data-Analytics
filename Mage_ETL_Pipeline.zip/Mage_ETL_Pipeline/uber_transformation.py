import pandas as pd
if 'transformer' not in globals():
    from mage_ai.data_preparation.decorators import transformer
if 'test' not in globals():
    from mage_ai.data_preparation.decorators import test


@transformer
def transform(df, *args, **kwargs):
    """
    Template code for a transformer block.

    Add more parameters to this function if this block has multiple parent blocks.
    There should be one parameter for each output variable from each parent block.

    Args:
        data: The output from the upstream parent block
        args: The output from any additional upstream blocks (if applicable)

    Returns:
        Anything (e.g. data frame, dictionary, array, int, str, etc.)
    """
    # Specify your transformation logic here
    start_date_dim = df[['start_date', 'start_hour', 'start_minute']].drop_duplicates().reset_index(drop=True)
    start_date_dim['start_date_id'] = start_date_dim.index
    start_date_dim = start_date_dim[['start_date_id', 'start_date', 'start_hour', 'start_minute']]

    end_date_dim = df[['end_date', 'end_hour', 'end_minute', 'year']].drop_duplicates().reset_index(drop=True)
    end_date_dim['end_date_id'] = end_date_dim.index
    end_date_dim = end_date_dim[['end_date_id', 'end_date', 'end_hour', 'end_minute', 'year']]

    category_dim = df[['category']].drop_duplicates().reset_index(drop=True)
    category_dim['category_id'] = category_dim.index
    category_dim = category_dim[['category_id', 'category']]

    start_location_dim = df[['start']].drop_duplicates().reset_index(drop=True)
    start_location_dim['start_location_id'] = start_location_dim.index
    start_location_dim = start_location_dim[['start_location_id', 'start']]

    end_location_dim = df[['stop']].drop_duplicates().reset_index(drop=True)
    end_location_dim['end_location_id'] = end_location_dim.index
    end_location_dim = end_location_dim[['end_location_id', 'stop']]

    purpose_dim = df[['purpose']].drop_duplicates().reset_index(drop=True)
    purpose_dim['purpose_id'] = purpose_dim.index
    purpose_dim = purpose_dim[['purpose_id', 'purpose']]

    # Step 1: Backup the original metric columns BEFORE merging
    metrics = df[['trip_id', 'miles', 'duration', 'speed', 'day', 'day_time']]

    # Step 2: Merge all dimension tables
    fact_table = df.merge(start_date_dim, on=['start_date', 'start_hour', 'start_minute']) \
        .merge(end_date_dim, on=['end_date', 'end_hour', 'end_minute', 'year']) \
        .merge(category_dim, on='category') \
        .merge(start_location_dim, on='start') \
        .merge(end_location_dim, on='stop') \
        .merge(purpose_dim, on='purpose')

    # Step 3: Merge the metrics back after all dimension joins
    fact_table = fact_table.merge(metrics, on='trip_id', how='left')

    # Step 4: Select final columns (dimension keys + facts)
    [[
        'trip_id',
        'start_date_id',
        'end_date_id',
        'start_location_id',
        'end_location_id',
        'category_id',
        'purpose_id',
        'miles',
        'duration',
        'speed',
        'day',
        'day_time'
    ]]

    print(fact_table)
    return "success"


@test
def test_output(output, *args) -> None:
    """
    Template code for testing the output of the block.
    """
    assert output is not None, 'The output is undefined'